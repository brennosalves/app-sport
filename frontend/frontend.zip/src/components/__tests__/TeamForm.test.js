import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import TeamForm from '../TeamForm'; // Update import to TeamForm

describe('TeamForm', () => {
    it('calls onAdd with correct data when form is submitted', () => {
        const mockShowMessage = jest.fn(); // Mocking showMessage function to pass as prop
        const mockSetTeams = jest.fn(); // Mocking setTeams function
        
        render(<TeamForm showMessage={mockShowMessage} setTeams={mockSetTeams} />); // Render the TeamForm with mock functions

        // Simulate user typing in the input fields
        fireEvent.change(screen.getByLabelText(/Team Name/i), { target: { value: 'Arsenal' } });
        fireEvent.change(screen.getByLabelText(/Team Badge URL/i), { target: { value: 'https://www.thesportsdb.com/images/media/team/badge/uyhbfe1612467038.png' } });
        fireEvent.change(screen.getByLabelText(/Stadium Name/i), { target: { value: 'Emirates Stadium' } });

        // Simulate form submission
        fireEvent.click(screen.getByRole('button', { name: /Create Team/i }));

        // Check if showMessage was called (indicating successful form submission)
        expect(mockShowMessage).toHaveBeenCalledWith('Team added successfully!', 'success');
    });

    it('clears the inputs after form submission', () => {
        const mockShowMessage = jest.fn();
        const mockSetTeams = jest.fn();

        render(<TeamForm showMessage={mockShowMessage} setTeams={mockSetTeams} />);

        // Simulate user typing in the input fields
        fireEvent.change(screen.getByLabelText(/Team Name/i), { target: { value: 'Arsenal' } });
        fireEvent.change(screen.getByLabelText(/Team Badge URL/i), { target: { value: 'https://www.thesportsdb.com/images/media/team/badge/uyhbfe1612467038.png' } });
        fireEvent.change(screen.getByLabelText(/Stadium Name/i), { target: { value: 'Emirates Stadium' } });

        // Simulate form submission
        fireEvent.click(screen.getByRole('button', { name: /Create Team/i }));

        // Check that inputs are cleared
        expect(screen.getByLabelText(/Team Name/i).value).toBe('');
        expect(screen.getByLabelText(/Team Badge URL/i).value).toBe('');
        expect(screen.getByLabelText(/Stadium Name/i).value).toBe('');
    });
});
