import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import TeamList from '../TeamList';

// Mock the fetch function globally before the test runs
beforeEach(() => {
  global.fetch = jest.fn(() =>
    Promise.resolve({
      json: () =>
        Promise.resolve([
          { id: '1', name: 'Arsenal', strStadium: 'Emirates Stadium' },
          { id: '2', name: 'Chelsea', strStadium: 'Stamford Bridge' },
        ]),
    })
  );
});

describe('TeamList', () => {
  it('renders fetched team data correctly', async () => {
    render(<TeamList />);

    // Check if loading text is shown first
    expect(screen.getByText(/loading/i)).toBeInTheDocument();

    // Wait for the fetch to complete and the teams to render
    await waitFor(() => screen.getByText('Arsenal - Emirates Stadium'));
    await waitFor(() => screen.getByText('Chelsea - Stamford Bridge'));

    // Check that the teams and their stadiums are rendered correctly
    expect(screen.getByText('Arsenal - Emirates Stadium')).toBeInTheDocument();
    expect(screen.getByText('Chelsea - Stamford Bridge')).toBeInTheDocument();
  });
});
