import React, { useState } from 'react';
import Message from './Message';  // Import the Message component

const TeamForm = ({ showMessage, message, messageType, setTeams }) => {
  const [name, setName] = useState("");
  const [strBadge, setStrBadge] = useState("");
  const [strStadium, setStrStadium] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    const newTeamData = { name, strBadge, strStadium };

    fetch('http://localhost:5010/teams', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newTeamData),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.message === 'Team added successfully') {
          setTeams((prevTeams) => [...prevTeams, data.team]);
          showMessage('Team added successfully!', 'success');
          setName('');
          setStrBadge('');
          setStrStadium('');
        } else {
          showMessage('Failed to add team: ' + data.message, 'error');
        }
      })
      .catch((error) => {
        showMessage('Error adding team. Please try again later.', 'error');
      });
  };

  return (
    <div className="team-form">
      <h2>Create a Team</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Team Name</label>
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
        <div className="form-group">
          <label>Team Badge URL</label>
          <input type="url" value={strBadge} onChange={(e) => setStrBadge(e.target.value)} required />
        </div>
        <div className="form-group">
          <label>Stadium Name</label>
          <input type="text" value={strStadium} onChange={(e) => setStrStadium(e.target.value)} required />
        </div>
        <button type="submit">Create Team</button>

        {/* Show Message Below the Button */}
        <Message message={message} messageType={messageType} />
      </form>
    </div>
  );
};

export default TeamForm;
