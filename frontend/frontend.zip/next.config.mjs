/** @type {import('next').NextConfig} */
const nextConfig = {devIndicators: {autoPrerender: false}};

export default nextConfig;
